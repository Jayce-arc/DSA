# ☕ Brew Haven Coffee — POS System
### Complete Windows Forms Point-of-Sale Application in C#

---

## 📁 Project Structure

```
CoffeeShopPOS/
├── Program.cs                  ← Application entry point
│
├── Models/
│   ├── AddOn.cs                ← Add-on option (extra shot, oat milk, etc.)
│   ├── MenuItem.cs             ← Menu item with size-based pricing
│   ├── OrderItem.cs            ← A single item in the cart (item + size + add-ons + qty)
│   └── Order.cs                ← The full cart with subtotal / tax / total
│
├── Data/
│   └── MenuData.cs             ← Static registry of ALL 32 menu items + 12 add-ons
│
├── Helpers/
│   ├── ColorPalette.cs         ← Centralised warm-coffee colour constants
│   └── ImageGenerator.cs       ← GDI+ icon renderer (no external image files needed)
│
└── Forms/
    ├── MainForm.cs             ← Main POS screen (menu grid + order sidebar)
    ├── CustomizationForm.cs    ← Modal: choose size / add-ons / quantity
    └── ReceiptForm.cs          ← Thermal-style receipt window with print support
```

---

## ⚡ Quick Setup (Visual Studio)

### Option A — New project, add files
1. Open **Visual Studio 2022** (or 2019).
2. Create a new project → **Windows Forms App (.NET 6 / .NET 8)** → name it `CoffeeShopPOS`.
3. Delete the auto-generated `Form1.cs` and `Form1.Designer.cs`.
4. In Solution Explorer, create folders: `Models`, `Data`, `Helpers`, `Forms`.
5. **Add → Existing Item** → add each `.cs` file to its matching folder.
6. Press **F5** to run.

> **Target Framework**: .NET 6.0-windows or .NET 8.0-windows  
> **No NuGet packages required** — pure .NET BCL + Windows Forms.

### Option B — .NET Framework 4.7.2+
The code is compatible with **.NET Framework 4.7.2+** with one change:

In `MenuItem.cs`, replace the `switch` expression with:
```csharp
public decimal GetPriceForSize(string size) {
    if (!HasSizes || string.IsNullOrEmpty(size)) return BasePrice;
    if (size == "Medium") return BasePrice + 20m;
    if (size == "Large")  return BasePrice + 40m;
    return BasePrice;
}
```
(Already written this way — no changes needed.)

---

## 🖥️ UI Overview

```
┌─────────────────────────────────────────────────────────┬──────────────┐
│  ☕ BREW HAVEN    Coffee & Pastry Shop        TXN #1001 │              │
├──────────────────────────────────────────────────────── │  🛒 ORDER    │
│  [All] [Hot Coffee] [Cold Coffee] [Pastries] [Extras]   │              │
├─────────────────────────────────────────────────────────│  Item rows   │
│                                                         │  (scrollable)│
│  [Card][Card][Card][Card][Card]                         │              │
│  [Card][Card][Card][Card][Card]   ← FlowLayoutPanel     ├──────────────│
│  [Card][Card][Card][Card]            (scrollable)       │ Subtotal     │
│                                                         │ VAT (12%)    │
│                                                         │ TOTAL        │
│                                                         ├──────────────│
│                                                         │ Cash: [____] │
│                                                         │ Change: ₱0   │
│                                                         │ [✓ CHARGE]   │
│                                                         │ [✕ Clear]    │
└─────────────────────────────────────────────────────────┴──────────────┘
```

---

## 🎯 Feature Checklist

| Feature | Status |
|---|---|
| 32 menu items across 4 categories | ✅ |
| GDI+ illustrated icons (no image files) | ✅ |
| Category filter buttons | ✅ |
| Click card → Customisation dialog | ✅ |
| Size selection S / M / L (+₱20 / +₱40) | ✅ |
| 12 add-on options with prices | ✅ |
| Quantity +/− in dialog | ✅ |
| Live price update in dialog | ✅ |
| Cart merges identical items | ✅ |
| Per-item qty control in sidebar | ✅ |
| Per-item delete button | ✅ |
| Subtotal / VAT 12% / Total | ✅ |
| Cash tendered input | ✅ |
| Live change calculation | ✅ |
| Validation (empty order, short payment) | ✅ |
| Thermal-style receipt window | ✅ |
| Itemised list with add-ons on receipt | ✅ |
| Print receipt via PrintDialog | ✅ |
| Transaction counter + timestamp | ✅ |
| Live clock in header | ✅ |
| Hover effects on cards | ✅ |
| Green flash confirmation on add | ✅ |
| Warm coffee colour palette throughout | ✅ |
| OOP: Model / Data / Helper / Form layers | ✅ |

---

## 🔧 Customisation

### Adding a new menu item
Open `Data/MenuData.cs` and add a `new MenuItem(...)` to `GetAllMenuItems()`:
```csharp
new MenuItem(
    id:          33,
    name:        "Lavender Latte",
    category:    "Hot Coffee",
    basePrice:   165m,
    description: "Espresso with steamed oat milk & lavender syrup",
    hasSizes:    true,
    imageType:   "hot",          // ← uses hot cup icon; add new type to ImageGenerator for custom art
    themeColor:  Color.FromArgb(180, 140, 200)
),
```

### Adding a new add-on
Open `Data/MenuData.cs` → `GetAvailableAddOns()`:
```csharp
new AddOn("Lavender Syrup", 20m),
```

### Changing tax rate
Open `Models/Order.cs`:
```csharp
public const decimal TAX_RATE = 0.12m;   // change to 0.10 for 10%, etc.
```

### Changing size upcharges
Open `Models/MenuItem.cs` → `GetPriceForSize()`.

---

## 🖨️ Receipt Print Note
The receipt uses `System.Drawing.Printing.PrintDocument`.
On first run, a **Print Dialog** will appear letting the cashier choose the printer.
For thermal POS printers (80mm width), set paper size to **72mm × custom** in printer settings.

---

## 📐 Design Principles Applied
1. **Visual Hierarchy** — Espresso header → Mocha category bar → light cream canvas  
2. **Accessibility** — High contrast text, large touch targets (card 162×190px)  
3. **Consistency** — Unified colour palette via `ColorPalette.cs`  
4. **Feedback** — Green flash on add, colour-coded change (red = insufficient)  
5. **Efficiency** — Cart auto-merges duplicates; single click to open customisation  
6. **Error Prevention** — Validation before charge, confirmation before clear  
7. **OOP Separation** — Models know nothing about UI; Forms know nothing about drawing  

---

*Built with ❤️ and ☕ — Brew Haven POS v1.0*
