using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using CoffeeShopPOS.Data;
using CoffeeShopPOS.Helpers;
using CoffeeShopPOS.Models;

namespace CoffeeShopPOS.Forms
{
    /// <summary>
    /// Modal dialog that lets the cashier customise a menu item
    /// before adding it to the active order.
    /// </summary>
    public class CustomizationForm : Form
    {
        // ── Data ──────────────────────────────────────────────────────────
        private readonly MenuItem       _item;
        private readonly List<AddOn>    _addOns;
        private string                  _selectedSize = "Medium";
        private int                     _quantity     = 1;

        // ── Controls ──────────────────────────────────────────────────────
        private PictureBox              _imgItem;
        private Label                   _lblName, _lblDescription;
        private Panel                   _pnlSizes;
        private Button                  _btnSmall, _btnMedium, _btnLarge;
        private FlowLayoutPanel         _flpAddOns;
        private Label                   _lblQty;
        private Button                  _btnMinus, _btnPlus;
        private Label                   _lblPrice;
        private Button                  _btnAdd, _btnCancel;

        // ── Public result ─────────────────────────────────────────────────
        public OrderItem ResultItem { get; private set; }

        // ──────────────────────────────────────────────────────────────────
        public CustomizationForm(MenuItem item)
        {
            _item   = item;
            _addOns = MenuData.GetAvailableAddOns();

            InitialiseComponent();
            LoadItemData();
        }

        // ── Build UI ──────────────────────────────────────────────────────
        private void InitialiseComponent()
        {
            Text            = "Customise Your Order";
            Size            = new Size(460, 620);
            StartPosition   = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.None;
            BackColor       = ColorPalette.LightCream;
            Font            = new Font("Segoe UI", 9.5f);

            // ── Header strip ─────────────────────────────────────────────
            var header = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 56,
                BackColor = ColorPalette.Espresso
            };
            var lblTitle = new Label
            {
                Text      = "Customise Your Order",
                ForeColor = ColorPalette.Cream,
                Font      = new Font("Segoe UI", 13f, FontStyle.Bold),
                AutoSize  = false,
                Bounds    = new Rectangle(0, 0, 410, 56),
                TextAlign = ContentAlignment.MiddleCenter
            };
            var btnClose = new Button
            {
                Text      = "✕",
                ForeColor = ColorPalette.Cream,
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Bounds    = new Rectangle(415, 10, 35, 35),
                Font      = new Font("Segoe UI", 11f),
                Cursor    = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            header.Controls.Add(lblTitle);
            header.Controls.Add(btnClose);

            // ── Body scroll panel ─────────────────────────────────────────
            var scroll = new Panel
            {
                Location    = new Point(0, 56),
                Size        = new Size(460, 490),
                AutoScroll  = true,
                BackColor   = ColorPalette.LightCream
            };

            int y = 14;

            // Item image + name
            _imgItem = new PictureBox
            {
                Location    = new Point(20, y),
                Size        = new Size(90, 82),
                SizeMode    = PictureBoxSizeMode.Zoom,
                BackColor   = Color.White
            };
            DrawRoundCorners(_imgItem, 10);

            _lblName = new Label
            {
                Location  = new Point(124, y + 4),
                Size      = new Size(310, 32),
                Font      = new Font("Segoe UI", 14f, FontStyle.Bold),
                ForeColor = ColorPalette.Espresso
            };
            _lblDescription = new Label
            {
                Location  = new Point(124, y + 38),
                Size      = new Size(310, 38),
                Font      = new Font("Segoe UI", 9.5f),
                ForeColor = ColorPalette.TextMuted
            };
            scroll.Controls.Add(_imgItem);
            scroll.Controls.Add(_lblName);
            scroll.Controls.Add(_lblDescription);
            y += 96;

            // Divider
            scroll.Controls.Add(Divider(y)); y += 16;

            // ── Size section ──────────────────────────────────────────────
            _pnlSizes = new Panel { Location = new Point(20, y), Size = new Size(420, 90) };

            var lblSize = SectionHeader("Size Selection");
            lblSize.Location = new Point(0, 0);
            _pnlSizes.Controls.Add(lblSize);

            _btnSmall  = SizeButton("S\n₱{0:F0}", 0,  50, _item.BasePrice);
            _btnMedium = SizeButton("M\n₱{0:F0}", 110, 50, _item.BasePrice + 20);
            _btnLarge  = SizeButton("L\n₱{0:F0}", 220, 50, _item.BasePrice + 40);

            _btnSmall.Click  += (s, e) => SelectSize("Small",  _btnSmall);
            _btnMedium.Click += (s, e) => SelectSize("Medium", _btnMedium);
            _btnLarge.Click  += (s, e) => SelectSize("Large",  _btnLarge);

            _pnlSizes.Controls.Add(_btnSmall);
            _pnlSizes.Controls.Add(_btnMedium);
            _pnlSizes.Controls.Add(_btnLarge);

            scroll.Controls.Add(_pnlSizes);
            y += 96;

            // ── Add-ons section ───────────────────────────────────────────
            scroll.Controls.Add(Divider(y)); y += 16;
            var lblAddOns = SectionHeader("Add-Ons & Extras");
            lblAddOns.Location = new Point(20, y);
            scroll.Controls.Add(lblAddOns);
            y += 28;

            _flpAddOns = new FlowLayoutPanel
            {
                Location    = new Point(20, y),
                Size        = new Size(420, 175),
                AutoSize    = false,
                WrapContents = true,
                BackColor   = Color.Transparent
            };

            foreach (var ao in _addOns)
            {
                var chk = new CheckBox
                {
                    Text      = ao.ToString(),
                    Tag       = ao,
                    AutoSize  = true,
                    Margin    = new Padding(4, 4, 16, 4),
                    Font      = new Font("Segoe UI", 9f),
                    ForeColor = ColorPalette.TextDark,
                    BackColor = Color.Transparent,
                    Cursor    = Cursors.Hand
                };
                chk.CheckedChanged += AddOn_CheckedChanged;
                _flpAddOns.Controls.Add(chk);
            }
            scroll.Controls.Add(_flpAddOns);
            y += 182;

            // ── Quantity section ──────────────────────────────────────────
            scroll.Controls.Add(Divider(y)); y += 16;
            var lblQtyLabel = SectionHeader("Quantity");
            lblQtyLabel.Location = new Point(20, y);
            scroll.Controls.Add(lblQtyLabel);
            y += 30;

            _btnMinus = RoundButton("−", new Point(20, y), ColorPalette.BtnClear);
            _lblQty   = new Label
            {
                Location  = new Point(70, y),
                Size      = new Size(60, 38),
                Text      = "1",
                TextAlign = ContentAlignment.MiddleCenter,
                Font      = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = ColorPalette.Espresso,
                BackColor = Color.Transparent
            };
            _btnPlus = RoundButton("+", new Point(132, y), ColorPalette.BtnCharge);

            _btnMinus.Click += (s, e) => { if (_quantity > 1) { _quantity--; _lblQty.Text = _quantity.ToString(); UpdatePrice(); } };
            _btnPlus.Click  += (s, e) => { if (_quantity < 20) { _quantity++; _lblQty.Text = _quantity.ToString(); UpdatePrice(); } };

            scroll.Controls.Add(_btnMinus);
            scroll.Controls.Add(_lblQty);
            scroll.Controls.Add(_btnPlus);

            // ── Total price ───────────────────────────────────────────────
            _lblPrice = new Label
            {
                Location  = new Point(210, y),
                Size      = new Size(220, 38),
                Font      = new Font("Segoe UI", 15f, FontStyle.Bold),
                ForeColor = ColorPalette.PriceGreen,
                TextAlign = ContentAlignment.MiddleRight,
                BackColor = Color.Transparent
            };
            scroll.Controls.Add(_lblPrice);

            // ── Add sizes panel if !HasSizes ─────────────────────────────
            if (!_item.HasSizes)
            {
                _pnlSizes.Visible = false;
                _selectedSize     = string.Empty;
            }
            else
            {
                SelectSize("Medium", _btnMedium); // default selection
            }

            Controls.Add(header);
            Controls.Add(scroll);

            // ── Footer buttons ────────────────────────────────────────────
            var footer = new Panel
            {
                Bounds    = new Rectangle(0, 548, 460, 72),
                BackColor = ColorPalette.Cream
            };

            _btnCancel = ActionButton("Cancel", new Point(20, 16), ColorPalette.BtnGray, 180);
            _btnAdd    = ActionButton("Add to Order  ✓", new Point(212, 16), ColorPalette.BtnCharge, 228);

            _btnCancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            _btnAdd.Click    += BtnAdd_Click;

            footer.Controls.Add(_btnCancel);
            footer.Controls.Add(_btnAdd);
            Controls.Add(footer);
        }

        private void LoadItemData()
        {
            _imgItem.Image = ImageGenerator.GetMenuItemImage(_item);
            _lblName.Text  = _item.Name;
            _lblDescription.Text = _item.Description;
            UpdatePrice();
        }

        // ── Size button factory ───────────────────────────────────────────
        private Button SizeButton(string fmt, int x, int y, decimal price)
        {
            var btn = new Button
            {
                Text      = string.Format(fmt, price),
                Location  = new Point(x, y),
                Size      = new Size(100, 36),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = ColorPalette.TextDark,
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            btn.FlatAppearance.BorderColor = ColorPalette.Divider;
            btn.FlatAppearance.BorderSize  = 1;
            return btn;
        }

        private Button RoundButton(string text, Point loc, Color color)
        {
            var btn = new Button
            {
                Text      = text,
                Location  = loc,
                Size      = new Size(38, 38),
                FlatStyle = FlatStyle.Flat,
                BackColor = color,
                ForeColor = Color.White,
                Font      = new Font("Segoe UI", 16f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private Button ActionButton(string text, Point loc, Color color, int width)
        {
            var btn = new Button
            {
                Text      = text,
                Location  = loc,
                Size      = new Size(width, 42),
                FlatStyle = FlatStyle.Flat,
                BackColor = color,
                ForeColor = Color.White,
                Font      = new Font("Segoe UI", 11f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private Label SectionHeader(string text)
        {
            return new Label
            {
                Text      = text,
                Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = ColorPalette.Mocha,
                AutoSize  = true,
                BackColor = Color.Transparent
            };
        }

        private Panel Divider(int y)
        {
            return new Panel
            {
                Location  = new Point(20, y),
                Size      = new Size(420, 1),
                BackColor = ColorPalette.Divider
            };
        }

        private static void DrawRoundCorners(Control ctrl, int radius)
        {
            ctrl.Paint += (s, e) =>
            {
                var c = s as Control;
                using (var path = new GraphicsPath())
                {
                    int d = radius * 2;
                    path.AddArc(0, 0, d, d, 180, 90);
                    path.AddArc(c.Width - d, 0, d, d, 270, 90);
                    path.AddArc(c.Width - d, c.Height - d, d, d, 0, 90);
                    path.AddArc(0, c.Height - d, d, d, 90, 90);
                    path.CloseFigure();
                    c.Region = new Region(path);
                }
            };
        }

        // ── Event Handlers ────────────────────────────────────────────────
        private void SelectSize(string size, Button activeBtn)
        {
            _selectedSize = size;
            foreach (Button b in new[] { _btnSmall, _btnMedium, _btnLarge })
            {
                b.BackColor = Color.White;
                b.ForeColor = ColorPalette.TextDark;
                b.FlatAppearance.BorderColor = ColorPalette.Divider;
            }
            activeBtn.BackColor = ColorPalette.Mocha;
            activeBtn.ForeColor = Color.White;
            activeBtn.FlatAppearance.BorderColor = ColorPalette.Mocha;
            UpdatePrice();
        }

        private void AddOn_CheckedChanged(object sender, EventArgs e)
        {
            var chk = (CheckBox)sender;
            var ao  = (AddOn)chk.Tag;
            ao.IsSelected = chk.Checked;
            UpdatePrice();
        }

        private void UpdatePrice()
        {
            decimal baseP  = _item.GetPriceForSize(_selectedSize);
            decimal addOns = _addOns.Where(a => a.IsSelected).Sum(a => a.Price);
            decimal total  = (baseP + addOns) * _quantity;
            _lblPrice.Text = $"Total: ₱{total:F2}";
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var selectedAddOns = _addOns.Select(a => a.Clone()).ToList();
            // Sync IsSelected from checkboxes
            foreach (CheckBox chk in _flpAddOns.Controls.OfType<CheckBox>())
            {
                var ao = selectedAddOns.FirstOrDefault(a => a.Name == ((AddOn)chk.Tag).Name);
                if (ao != null) ao.IsSelected = chk.Checked;
            }

            ResultItem = new OrderItem(_item, _selectedSize, selectedAddOns, _quantity);
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
