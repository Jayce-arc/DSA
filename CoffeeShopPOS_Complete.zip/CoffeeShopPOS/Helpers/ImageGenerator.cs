using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using CoffeeShopPOS.Models;

namespace CoffeeShopPOS.Helpers
{
    /// <summary>
    /// Generates distinctive icon bitmaps for each menu item type using pure GDI+.
    /// No external image files required — everything is drawn at runtime.
    /// </summary>
    public static class ImageGenerator
    {
        private const int W = 120;
        private const int H = 110;

        // ── Public API ────────────────────────────────────────────────────

        public static Bitmap GetMenuItemImage(MenuItem item)
        {
            switch (item.ImageType)
            {
                case "hot":        return DrawHotCup(item.ThemeColor);
                case "espresso":   return DrawEspressoShot(item.ThemeColor);
                case "cold":       return DrawColdCup(item.ThemeColor);
                case "frappe":     return DrawFrappe(item.ThemeColor);
                case "matcha":     return DrawMatcha();
                case "croissant":  return DrawCroissant();
                case "muffin":     return DrawMuffin(item.ThemeColor);
                case "roll":       return DrawCinnamonRoll();
                case "cake":       return DrawCakeSlice(item.ThemeColor);
                case "cheesecake": return DrawCheesecake();
                case "bread":      return DrawBananaBread();
                case "tart":       return DrawStrawberryTart();
                case "water":      return DrawWaterBottle();
                case "juice":      return DrawJuiceGlass();
                default:           return DrawDefault(item.ThemeColor);
            }
        }

        // ── Drawing Helpers ───────────────────────────────────────────────

        private static Graphics CreateCanvas(Bitmap bmp, Color bgTop, Color bgBot)
        {
            var g = Graphics.FromImage(bmp);
            g.SmoothingMode     = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            using (var brush = new LinearGradientBrush(
                new Rectangle(0, 0, W, H), bgTop, bgBot, 90f))
                g.FillRectangle(brush, 0, 0, W, H);
            return g;
        }

        private static GraphicsPath RoundedRect(int x, int y, int w, int h, int r)
        {
            var path = new GraphicsPath();
            path.AddArc(x,         y,         r * 2, r * 2, 180, 90);
            path.AddArc(x + w - r * 2, y,         r * 2, r * 2, 270, 90);
            path.AddArc(x + w - r * 2, y + h - r * 2, r * 2, r * 2,   0, 90);
            path.AddArc(x,         y + h - r * 2, r * 2, r * 2,  90, 90);
            path.CloseFigure();
            return path;
        }

        private static void DrawSteam(Graphics g, int cx)
        {
            using (var pen = new Pen(Color.FromArgb(120, 200, 200, 210), 2f)
                             { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                for (int i = -1; i <= 1; i++)
                {
                    int x = cx + i * 12;
                    g.DrawBezier(pen,
                        new Point(x,      38),
                        new Point(x - 6,  28),
                        new Point(x + 6,  20),
                        new Point(x,      10));
                }
            }
        }

        // ── Hot Cup ───────────────────────────────────────────────────────
        private static Bitmap DrawHotCup(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 248), Color.FromArgb(245, 235, 220)))
            {
                // Saucer
                using (var b = new SolidBrush(Blend(color, Color.White, 0.55f)))
                    g.FillEllipse(b, 22, 90, 76, 14);

                // Cup body (trapezoid)
                var body = new PointF[]
                {
                    new PointF(32, 42), new PointF(88, 42),
                    new PointF(82, 88), new PointF(38, 88),
                };
                using (var b = new SolidBrush(color))
                    g.FillPolygon(b, body);

                // Highlight on cup
                using (var b = new SolidBrush(Color.FromArgb(35, 255, 255, 255)))
                    g.FillPolygon(b, new PointF[] {
                        new PointF(36, 42), new PointF(56, 42),
                        new PointF(52, 88), new PointF(38, 88)});

                // Rim
                using (var b = new SolidBrush(Blend(color, Color.Black, 0.25f)))
                {
                    using (var path = RoundedRect(30, 38, 60, 8, 3))
                        g.FillPath(b, path);
                }

                // Handle
                using (var pen = new Pen(Blend(color, Color.Black, 0.2f), 5f)
                                 { StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawArc(pen, 76, 52, 26, 26, -70, 200);

                // Steam
                DrawSteam(g, 60);

                // Brand dot
                using (var b = new SolidBrush(Color.FromArgb(50, 255, 255, 255)))
                    g.FillEllipse(b, 44, 58, 18, 14);
            }
            return bmp;
        }

        // ── Espresso Shot ─────────────────────────────────────────────────
        private static Bitmap DrawEspressoShot(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 250, 245), Color.FromArgb(240, 228, 210)))
            {
                // Small round cup
                var cup = new PointF[]
                {
                    new PointF(38, 58), new PointF(82, 58),
                    new PointF(77, 92), new PointF(43, 92),
                };
                using (var b = new SolidBrush(color))
                    g.FillPolygon(b, cup);

                // Crema (golden foam on top)
                using (var b = new SolidBrush(Color.FromArgb(210, 165, 80)))
                {
                    using (var path = RoundedRect(35, 53, 50, 9, 4))
                        g.FillPath(b, path);
                }

                // Handle (smaller arc)
                using (var pen = new Pen(Blend(color, Color.Black, 0.3f), 4f))
                    g.DrawArc(pen, 74, 62, 18, 18, -70, 200);

                // Saucer
                using (var b = new SolidBrush(Blend(color, Color.White, 0.6f)))
                    g.FillEllipse(b, 28, 89, 64, 10);

                DrawSteam(g, 60);
            }
            return bmp;
        }

        // ── Cold Iced Cup ─────────────────────────────────────────────────
        private static Bitmap DrawColdCup(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(245, 250, 255), Color.FromArgb(230, 242, 252)))
            {
                // Cup body (straight sides for to-go cup)
                var body = new PointF[]
                {
                    new PointF(28, 30), new PointF(92, 30),
                    new PointF(86, 98), new PointF(34, 98),
                };

                // Fill with coffee color (semi-transparent layer)
                using (var b = new SolidBrush(Color.FromArgb(200, color.R, color.G, color.B)))
                    g.FillPolygon(b, body);

                // Ice cubes
                var icePen  = new Pen(Color.FromArgb(120, 180, 210, 230), 1f);
                var iceBrush = new SolidBrush(Color.FromArgb(120, 210, 235, 250));
                int[][] icePos = { new[]{40,50}, new[]{62,45}, new[]{50,65}, new[]{72,60} };
                foreach (var p in icePos)
                {
                    g.FillRectangle(iceBrush, p[0], p[1], 14, 14);
                    g.DrawRectangle(icePen,   p[0], p[1], 14, 14);
                }
                iceBrush.Dispose(); icePen.Dispose();

                // Condensation dots
                using (var b = new SolidBrush(Color.FromArgb(50, 180, 210, 240)))
                    for (int i = 0; i < 8; i++)
                        g.FillEllipse(b, 30 + i * 8, 38 + (i % 2) * 15, 4, 4);

                // Dome lid
                using (var b = new SolidBrush(Color.FromArgb(80, 200, 220, 240)))
                    g.FillEllipse(b, 26, 22, 68, 18);
                using (var pen = new Pen(Color.FromArgb(100, 160, 190, 210), 1.5f))
                    g.DrawEllipse(pen, 26, 22, 68, 18);

                // Straw
                using (var pen = new Pen(Color.FromArgb(210, 80, 100), 4f)
                                 { StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawLine(pen, 80, 5, 72, 100);

                // Cup outline
                using (var pen = new Pen(Color.FromArgb(80, Blend(color, Color.Black, 0.3f)), 1.5f))
                    g.DrawPolygon(pen, body);
            }
            return bmp;
        }

        // ── Frappe ────────────────────────────────────────────────────────
        private static Bitmap DrawFrappe(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(250, 248, 242), Color.FromArgb(238, 228, 212)))
            {
                // Tall glass
                var glass = new PointF[]
                {
                    new PointF(30, 28), new PointF(90, 28),
                    new PointF(82, 95), new PointF(38, 95),
                };
                using (var b = new SolidBrush(Color.FromArgb(190, color.R, color.G, color.B)))
                    g.FillPolygon(b, glass);

                // Whipped cream mound on top
                var creamColor = Color.FromArgb(250, 248, 242);
                using (var b = new SolidBrush(creamColor))
                {
                    g.FillEllipse(b, 25, 14, 70, 26);
                    g.FillEllipse(b, 35, 10, 50, 22);
                    g.FillEllipse(b, 45,  6, 30, 18);
                }
                using (var pen = new Pen(Color.FromArgb(60, 180, 150, 120), 1f))
                {
                    g.DrawEllipse(pen, 25, 14, 70, 26);
                    g.DrawEllipse(pen, 35, 10, 50, 22);
                }

                // Chocolate drizzle
                using (var pen = new Pen(Color.FromArgb(110, 65, 30), 2f)
                                 { DashStyle = DashStyle.Dot })
                    g.DrawBezier(pen, 38, 32, 52, 25, 68, 35, 82, 28);

                // Straw
                using (var pen = new Pen(Color.FromArgb(80, 160, 80), 4f)
                                 { StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawLine(pen, 76, 2, 68, 98);

                // Glass glare
                using (var b = new SolidBrush(Color.FromArgb(30, 255, 255, 255)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(35,30), new PointF(48,30),
                        new PointF(44,92), new PointF(38,92)});
            }
            return bmp;
        }

        // ── Matcha ────────────────────────────────────────────────────────
        private static Bitmap DrawMatcha()
        {
            var color = Color.FromArgb(106, 153, 85);
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(240, 248, 236), Color.FromArgb(220, 240, 215)))
            {
                // Tall glass (iced matcha)
                var glass = new PointF[]
                {
                    new PointF(28, 26), new PointF(92, 26),
                    new PointF(84, 96), new PointF(36, 96),
                };
                // Milk layer at bottom
                using (var b = new SolidBrush(Color.FromArgb(240, 235, 218)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(36,68), new PointF(84,68),
                        new PointF(84,96), new PointF(36,96)});
                // Matcha layer on top
                using (var b = new SolidBrush(color))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(28,26), new PointF(92,26),
                        new PointF(84,68), new PointF(36,68)});

                // Gradient mix zone
                using (var b = new LinearGradientBrush(
                    new Point(28,60), new Point(28,76),
                    Color.FromArgb(140, color.R, color.G, color.B),
                    Color.FromArgb(180, 240, 235, 218)))
                    g.FillRectangle(b, 36, 60, 48, 16);

                // Ice
                using (var ib = new SolidBrush(Color.FromArgb(120, 215, 235, 250)))
                using (var ip = new Pen(Color.FromArgb(80, 180, 210, 230), 1f))
                {
                    g.FillRectangle(ib, 40, 70, 12, 12); g.DrawRectangle(ip, 40, 70, 12, 12);
                    g.FillRectangle(ib, 60, 75, 12, 12); g.DrawRectangle(ip, 60, 75, 12, 12);
                }

                // Dome lid + straw
                using (var b = new SolidBrush(Color.FromArgb(60, 200, 220, 200)))
                    g.FillEllipse(b, 24, 18, 72, 18);
                using (var pen = new Pen(Color.FromArgb(255, 168, 200, 168), 4f))
                    g.DrawLine(pen, 82, 2, 74, 98);

                // Glass outline
                using (var pen = new Pen(Color.FromArgb(80, 106, 153, 85), 1.5f))
                    g.DrawPolygon(pen, glass);
            }
            return bmp;
        }

        // ── Croissant ─────────────────────────────────────────────────────
        private static Bitmap DrawCroissant()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 240), Color.FromArgb(250, 238, 210)))
            {
                // Main crescent body
                using (var path = new GraphicsPath())
                {
                    path.AddEllipse(18, 30, 84, 55);
                    using (var inner = new GraphicsPath())
                    {
                        inner.AddEllipse(30, 42, 60, 32);
                        var region = new Region(path);
                        region.Exclude(inner);
                        using (var b = new SolidBrush(Color.FromArgb(205, 155, 75)))
                            g.FillRegion(b, region);
                    }
                }

                // Golden brown top glaze
                using (var b = new SolidBrush(Color.FromArgb(100, 175, 120, 40)))
                {
                    g.FillEllipse(b, 20, 32, 40, 22);
                    g.FillEllipse(b, 60, 32, 40, 22);
                }

                // Layered texture lines
                using (var pen = new Pen(Color.FromArgb(80, 160, 110, 40), 1.2f))
                {
                    g.DrawArc(pen, 22, 34, 30, 18, 180, 180);
                    g.DrawArc(pen, 68, 34, 30, 18, 180, 180);
                    g.DrawArc(pen, 35, 38, 50, 28, 180, 180);
                }

                // Shine
                using (var b = new SolidBrush(Color.FromArgb(40, 255, 240, 180)))
                    g.FillEllipse(b, 30, 34, 25, 12);
            }
            return bmp;
        }

        // ── Muffin ────────────────────────────────────────────────────────
        private static Bitmap DrawMuffin(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 248), Color.FromArgb(245, 235, 220)))
            {
                // Paper cup (bottom)
                var cup = new PointF[]
                {
                    new PointF(35, 62), new PointF(85, 62),
                    new PointF(80, 96), new PointF(40, 96),
                };
                using (var b = new SolidBrush(Color.FromArgb(245, 235, 220)))
                    g.FillPolygon(b, cup);
                // Striped cup lines
                using (var pen = new Pen(Color.FromArgb(60, 180, 155, 125), 1f))
                    for (int x = 40; x <= 80; x += 8)
                        g.DrawLine(pen, x, 62, x - 3, 96);

                // Muffin dome
                using (var b = new SolidBrush(color))
                    g.FillEllipse(b, 20, 22, 80, 50);

                // Dome highlight
                using (var b = new SolidBrush(Color.FromArgb(35, 255, 255, 255)))
                    g.FillEllipse(b, 30, 26, 35, 22);

                // Blueberry dots (or chocolate chips)
                var dotColor = (color.B > 100 && color.R < 120)
                    ? Color.FromArgb(60, 40, 130)   // blueberry
                    : Color.FromArgb(40, 25, 15);   // chocolate
                using (var b = new SolidBrush(dotColor))
                {
                    g.FillEllipse(b, 45, 30, 10, 10);
                    g.FillEllipse(b, 62, 40, 10, 10);
                    g.FillEllipse(b, 35, 45, 10, 10);
                    g.FillEllipse(b, 70, 28, 9, 9);
                }
            }
            return bmp;
        }

        // ── Cinnamon Roll ─────────────────────────────────────────────────
        private static Bitmap DrawCinnamonRoll()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 240), Color.FromArgb(248, 235, 210)))
            {
                // Roll base circle
                using (var b = new SolidBrush(Color.FromArgb(205, 155, 80)))
                    g.FillEllipse(b, 18, 18, 84, 84);

                // Spiral rings
                using (var pen = new Pen(Color.FromArgb(160, 100, 40), 4f) { StartCap = LineCap.Round })
                {
                    g.DrawArc(pen, 28, 28, 64, 64, -30, 300);
                    g.DrawArc(pen, 38, 38, 44, 44,  10, 280);
                    g.DrawArc(pen, 48, 48, 24, 24,  30, 260);
                }

                // Icing drizzle
                using (var b = new SolidBrush(Color.FromArgb(180, 255, 250, 240)))
                {
                    g.FillEllipse(b, 20, 20, 80, 80);
                    // Drip effect
                    g.FillEllipse(b, 24, 75, 15, 20);
                    g.FillEllipse(b, 80, 72, 14, 18);
                }

                // Centre
                using (var b = new SolidBrush(Color.FromArgb(170, 115, 55)))
                    g.FillEllipse(b, 52, 52, 16, 16);
            }
            return bmp;
        }

        // ── Cake Slice ────────────────────────────────────────────────────
        private static Bitmap DrawCakeSlice(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 248, 242), Color.FromArgb(245, 232, 218)))
            {
                var slice = new PointF[]
                {
                    new PointF(60, 15), new PointF(95, 85), new PointF(25, 85)
                };

                // Layer 2 (bottom cake)
                using (var b = new SolidBrush(Blend(color, Color.White, 0.15f)))
                    g.FillPolygon(b, slice);

                // Frosting top layer
                using (var b = new SolidBrush(Color.FromArgb(250, 240, 235)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(60,15), new PointF(95,85), new PointF(25,85),
                        new PointF(25,75), new PointF(95,75)});
                using (var b = new SolidBrush(Color.FromArgb(250, 240, 235)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(58,15), new PointF(95,30), new PointF(95,38),
                        new PointF(25,38), new PointF(25,30), new PointF(62,15)});

                // Chocolate ganache on top
                using (var b = new SolidBrush(color))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(60,15), new PointF(95,30), new PointF(95,38),
                        new PointF(25,38), new PointF(25,30)});

                // Ganache drip
                using (var b = new SolidBrush(Color.FromArgb(180, color.R, color.G, color.B)))
                    g.FillEllipse(b, 30, 34, 12, 14);

                // Cherry on top
                using (var b = new SolidBrush(Color.FromArgb(210, 50, 50)))
                    g.FillEllipse(b, 55, 8, 14, 12);
                using (var pen = new Pen(Color.FromArgb(80, 150, 80), 1.5f))
                    g.DrawBezier(pen, 62, 8, 60, 2, 66, 2, 64, 8);

                // Outline
                using (var pen = new Pen(Color.FromArgb(60, color.R, color.G, color.B), 1.5f))
                    g.DrawPolygon(pen, slice);
            }
            return bmp;
        }

        // ── Cheesecake ────────────────────────────────────────────────────
        private static Bitmap DrawCheesecake()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 245), Color.FromArgb(250, 238, 215)))
            {
                var slice = new PointF[]
                {
                    new PointF(60, 14), new PointF(96, 88), new PointF(24, 88)
                };

                // Graham cracker base
                using (var b = new SolidBrush(Color.FromArgb(195, 155, 90)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(24,78), new PointF(96,78),
                        new PointF(96,88), new PointF(24,88)});

                // Cream filling
                using (var b = new SolidBrush(Color.FromArgb(252, 248, 232)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(60,14), new PointF(96,78),
                        new PointF(24,78)});

                // Strawberry topping
                using (var b = new SolidBrush(Color.FromArgb(200, 210, 60, 60)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(60,14), new PointF(96,40),
                        new PointF(24,40)});

                // Strawberry slices
                using (var b = new SolidBrush(Color.FromArgb(220, 60, 60)))
                {
                    g.FillEllipse(b, 46, 20, 16, 18);
                    g.FillEllipse(b, 65, 26, 14, 16);
                    g.FillEllipse(b, 38, 30, 12, 15);
                }

                using (var pen = new Pen(Color.FromArgb(60, 180, 130, 80), 1.5f))
                    g.DrawPolygon(pen, slice);
            }
            return bmp;
        }

        // ── Banana Bread ─────────────────────────────────────────────────
        private static Bitmap DrawBananaBread()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 240), Color.FromArgb(248, 235, 205)))
            {
                // Loaf shape
                using (var path = RoundedRect(15, 35, 90, 55, 8))
                {
                    using (var b = new SolidBrush(Color.FromArgb(185, 140, 70)))
                        g.FillPath(b, path);
                }

                // Crack on top
                using (var pen = new Pen(Color.FromArgb(215, 165, 85), 3f)
                                 { StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawBezier(pen, 30, 36, 50, 30, 70, 38, 90, 34);

                // Texture dots (banana bits)
                using (var b = new SolidBrush(Color.FromArgb(160, 115, 45)))
                {
                    g.FillEllipse(b, 35, 50, 14, 8);
                    g.FillEllipse(b, 60, 55, 14, 8);
                    g.FillEllipse(b, 45, 68, 14, 8);
                    g.FillEllipse(b, 75, 48, 10, 6);
                }

                // Top glaze
                using (var b = new SolidBrush(Color.FromArgb(25, 255, 240, 180)))
                    using (var path = RoundedRect(15, 35, 90, 28, 8))
                        g.FillPath(b, path);
            }
            return bmp;
        }

        // ── Strawberry Tart ───────────────────────────────────────────────
        private static Bitmap DrawStrawberryTart()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 248, 245), Color.FromArgb(252, 235, 228)))
            {
                // Tart shell
                using (var b = new SolidBrush(Color.FromArgb(200, 160, 90)))
                    g.FillEllipse(b, 14, 30, 92, 62);
                using (var b = new SolidBrush(Color.FromArgb(175, 135, 70)))
                    g.FillEllipse(b, 20, 36, 80, 52);

                // Cream filling
                using (var b = new SolidBrush(Color.FromArgb(252, 248, 230)))
                    g.FillEllipse(b, 24, 40, 72, 44);

                // Strawberry pieces (red circles)
                using (var b = new SolidBrush(Color.FromArgb(225, 60, 70)))
                {
                    g.FillEllipse(b, 36, 42, 24, 22);
                    g.FillEllipse(b, 65, 45, 22, 20);
                    g.FillEllipse(b, 48, 60, 22, 20);
                }

                // Seed dots
                using (var pen = new Pen(Color.FromArgb(255, 200, 100), 1f))
                {
                    g.DrawEllipse(pen, 40, 46, 4, 4);
                    g.DrawEllipse(pen, 50, 52, 4, 4);
                    g.DrawEllipse(pen, 68, 48, 4, 4);
                }

                // Glaze shine
                using (var b = new SolidBrush(Color.FromArgb(30, 255, 160, 160)))
                    g.FillEllipse(b, 24, 40, 72, 44);
            }
            return bmp;
        }

        // ── Water Bottle ─────────────────────────────────────────────────
        private static Bitmap DrawWaterBottle()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(240, 248, 255), Color.FromArgb(220, 238, 252)))
            {
                using (var path = RoundedRect(36, 20, 48, 82, 10))
                {
                    using (var b = new LinearGradientBrush(
                        new Rectangle(36, 20, 48, 82),
                        Color.FromArgb(140, 190, 230, 255),
                        Color.FromArgb(140, 150, 200, 240), 0f))
                        g.FillPath(b, path);
                    using (var pen = new Pen(Color.FromArgb(120, 160, 200, 230), 1.5f))
                        g.DrawPath(pen, path);
                }

                // Label area
                using (var b = new SolidBrush(Color.FromArgb(50, 255, 255, 255)))
                    g.FillRectangle(b, 38, 50, 44, 30);

                // Water waves inside
                using (var pen = new Pen(Color.FromArgb(80, 100, 170, 220), 2f))
                {
                    g.DrawBezier(pen, 38, 70, 52, 64, 68, 76, 82, 70);
                    g.DrawBezier(pen, 38, 80, 52, 74, 68, 86, 82, 80);
                }

                // Cap
                using (var b = new SolidBrush(Color.FromArgb(100, 170, 210)))
                    using (var path = RoundedRect(42, 14, 36, 10, 4))
                        g.FillPath(b, path);

                // Glare
                using (var b = new SolidBrush(Color.FromArgb(60, 255, 255, 255)))
                    g.FillEllipse(b, 40, 24, 16, 40);
            }
            return bmp;
        }

        // ── Orange Juice ─────────────────────────────────────────────────
        private static Bitmap DrawJuiceGlass()
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 235), Color.FromArgb(250, 238, 210)))
            {
                // Glass body
                var glass = new PointF[]
                {
                    new PointF(30, 28), new PointF(90, 28),
                    new PointF(82, 96), new PointF(38, 96),
                };
                using (var b = new SolidBrush(Color.FromArgb(200, 240, 160, 20)))
                    g.FillPolygon(b, glass);

                // Pulp dots
                using (var b = new SolidBrush(Color.FromArgb(120, 220, 120, 15)))
                    for (int i = 0; i < 12; i++)
                        g.FillEllipse(b, 34 + (i * 5 % 46), 35 + i * 5, 6, 4);

                // Glass glare
                using (var b = new SolidBrush(Color.FromArgb(40, 255, 255, 255)))
                    g.FillPolygon(b, new PointF[]{
                        new PointF(34,30), new PointF(48,30),
                        new PointF(44,94), new PointF(38,94)});

                // Orange slice on rim
                using (var b = new SolidBrush(Color.FromArgb(240, 160, 20)))
                    g.FillEllipse(b, 72, 18, 30, 30);
                using (var b = new SolidBrush(Color.FromArgb(255, 200, 40)))
                    g.FillEllipse(b, 74, 20, 26, 26);
                // Segments
                using (var pen = new Pen(Color.FromArgb(200, 200, 120, 20), 1f))
                    for (int i = 0; i < 6; i++)
                        g.DrawLine(pen, 87, 33,
                            87 + (int)(12 * Math.Cos(i * Math.PI / 3)),
                            33 + (int)(12 * Math.Sin(i * Math.PI / 3)));

                using (var pen = new Pen(Color.FromArgb(80, 200, 140, 20), 1.5f))
                    g.DrawPolygon(pen, glass);
            }
            return bmp;
        }

        // ── Default ───────────────────────────────────────────────────────
        private static Bitmap DrawDefault(Color color)
        {
            var bmp = new Bitmap(W, H);
            using (var g = CreateCanvas(bmp, Color.FromArgb(255, 252, 248), Color.FromArgb(245, 235, 220)))
            {
                using (var b = new SolidBrush(Color.FromArgb(180, color.R, color.G, color.B)))
                    g.FillEllipse(b, 20, 15, 80, 80);
                using (var b = new SolidBrush(Color.FromArgb(60, 255, 255, 255)))
                    g.FillEllipse(b, 28, 22, 30, 22);
            }
            return bmp;
        }

        // ── Utility ───────────────────────────────────────────────────────
        private static Color Blend(Color c1, Color c2, float t)
        {
            return Color.FromArgb(
                (int)(c1.R + (c2.R - c1.R) * t),
                (int)(c1.G + (c2.G - c1.G) * t),
                (int)(c1.B + (c2.B - c1.B) * t));
        }
    }
}
