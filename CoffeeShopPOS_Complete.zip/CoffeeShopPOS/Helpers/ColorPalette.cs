using System.Drawing;

namespace CoffeeShopPOS.Helpers
{
    /// <summary>
    /// Centralised colour palette inspired by warm coffee tones.
    /// Espresso → Mocha → Latte → Cream progression gives clear visual hierarchy.
    /// </summary>
    public static class ColorPalette
    {
        // ── Brand ─────────────────────────────────────────────────────────
        public static readonly Color Espresso   = Color.FromArgb( 44,  24,  16);
        public static readonly Color DarkMocha  = Color.FromArgb( 74,  44,  28);
        public static readonly Color Mocha      = Color.FromArgb(101,  67,  33);
        public static readonly Color Coffee     = Color.FromArgb(139,  90,  43);
        public static readonly Color Latte      = Color.FromArgb(188, 143,  95);
        public static readonly Color Caramel    = Color.FromArgb(230, 175, 100);
        public static readonly Color Cream      = Color.FromArgb(255, 248, 235);
        public static readonly Color LightCream = Color.FromArgb(255, 252, 248);

        // ── Structural ────────────────────────────────────────────────────
        public static readonly Color HeaderBg       = Color.FromArgb( 44,  24,  16); // espresso
        public static readonly Color HeaderText     = Color.FromArgb(255, 248, 235); // cream
        public static readonly Color SidebarBg      = Color.FromArgb(250, 244, 235);
        public static readonly Color MenuBg         = Color.FromArgb(255, 252, 248);
        public static readonly Color CardBg         = Color.White;
        public static readonly Color CardHover      = Color.FromArgb(255, 248, 232);
        public static readonly Color CardBorder     = Color.FromArgb(230, 210, 190);
        public static readonly Color CategoryBar    = Color.FromArgb( 64,  38,  22);
        public static readonly Color CategoryActive = Color.FromArgb(255, 195,  80); // golden highlight
        public static readonly Color CategoryText   = Color.FromArgb(240, 220, 200);
        public static readonly Color Divider        = Color.FromArgb(220, 200, 178);

        // ── Typography ────────────────────────────────────────────────────
        public static readonly Color TextDark   = Color.FromArgb( 30,  20,  10);
        public static readonly Color TextMid    = Color.FromArgb( 80,  55,  35);
        public static readonly Color TextMuted  = Color.FromArgb(140, 115,  90);
        public static readonly Color TextLight  = Color.White;
        public static readonly Color PriceGreen = Color.FromArgb( 55, 140,  80);

        // ── Actions ───────────────────────────────────────────────────────
        public static readonly Color BtnCharge  = Color.FromArgb( 55, 140,  80); // green – confirm
        public static readonly Color BtnClear   = Color.FromArgb(190,  55,  55); // red   – danger
        public static readonly Color BtnRemove  = Color.FromArgb(210,  80,  80);
        public static readonly Color BtnGray    = Color.FromArgb(160, 140, 120);

        // ── Order Panel ───────────────────────────────────────────────────
        public static readonly Color OrderPanelBg = Color.FromArgb(250, 244, 235);
        public static readonly Color TotalBarBg   = Color.FromArgb( 44,  24,  16);
        public static readonly Color TotalBarText = Color.FromArgb(255, 195,  80);
    }
}
