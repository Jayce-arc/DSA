using System;
using System.Collections.Generic;
using System.Linq;

namespace CoffeeShopPOS.Models
{
    public class Order
    {
        public List<OrderItem> Items { get; private set; }
        public DateTime CreatedAt   { get; private set; }

        public const decimal TAX_RATE = 0.12m;

        public decimal Subtotal  => Items.Sum(i => i.TotalPrice);
        public decimal TaxAmount => Math.Round(Subtotal * TAX_RATE, 2);
        public decimal Total     => Subtotal + TaxAmount;
        public int     ItemCount => Items.Sum(i => i.Quantity);

        public Order()
        {
            Items     = new List<OrderItem>();
            CreatedAt = DateTime.Now;
        }

        /// <summary>
        /// Adds an item to the order.
        /// If an identical item (same ID, size, add-ons) already exists, increments its quantity.
        /// </summary>
        public void AddItem(OrderItem item)
        {
            var existing = Items.FirstOrDefault(i => i.CartKey == item.CartKey);
            if (existing != null)
                existing.Quantity += item.Quantity;
            else
                Items.Add(item);
        }

        public void RemoveItemAt(int index)
        {
            if (index >= 0 && index < Items.Count)
                Items.RemoveAt(index);
        }

        public void Clear()
        {
            Items.Clear();
            CreatedAt = DateTime.Now;
        }

        public decimal CalculateChange(decimal amountPaid)
        {
            return amountPaid - Total;
        }
    }
}
