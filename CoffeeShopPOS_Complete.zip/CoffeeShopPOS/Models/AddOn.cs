namespace CoffeeShopPOS.Models
{
    public class AddOn
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public bool IsSelected { get; set; }

        public AddOn(string name, decimal price)
        {
            Name  = name;
            Price = price;
            IsSelected = false;
        }

        public AddOn Clone()
        {
            return new AddOn(Name, Price) { IsSelected = IsSelected };
        }

        public override string ToString()
        {
            return Price > 0 ? $"{Name} (+₱{Price:F0})" : Name;
        }
    }
}
