using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoffeeShopPOS.Models
{
    public class OrderItem
    {
        public MenuItem    Item             { get; set; }
        public string      Size             { get; set; }
        public List<AddOn> SelectedAddOns   { get; set; }
        public int         Quantity         { get; set; }

        public decimal UnitPrice
        {
            get
            {
                decimal price = Item.GetPriceForSize(Size);
                if (SelectedAddOns != null)
                    price += SelectedAddOns.Where(a => a.IsSelected).Sum(a => a.Price);
                return price;
            }
        }

        public decimal TotalPrice => UnitPrice * Quantity;

        public string DisplayName
        {
            get
            {
                var sb = new StringBuilder(Item.Name);
                if (Item.HasSizes && !string.IsNullOrEmpty(Size))
                    sb.Append($" ({Size[0]})"); // S / M / L abbreviation
                return sb.ToString();
            }
        }

        public string AddOnsDescription
        {
            get
            {
                var active = SelectedAddOns?.Where(a => a.IsSelected).ToList();
                if (active == null || !active.Any()) return string.Empty;
                return string.Join(", ", active.Select(a => a.Name));
            }
        }

        /// <summary>Unique key used to merge duplicate items in the cart.</summary>
        public string CartKey => $"{Item.Id}|{Size}|{AddOnsDescription}";

        public OrderItem(MenuItem item, string size, List<AddOn> addOns, int quantity = 1)
        {
            Item           = item;
            Size           = size;
            SelectedAddOns = addOns ?? new List<AddOn>();
            Quantity       = quantity;
        }
    }
}
