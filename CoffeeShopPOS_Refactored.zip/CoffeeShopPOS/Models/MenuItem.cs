using System.Drawing;

namespace CoffeeShopPOS.Models
{
    public class MenuItem
    {
        public int     Id          { get; set; }
        public string  Name        { get; set; }
        public string  Category    { get; set; }
        public decimal BasePrice   { get; set; }
        public string  Description { get; set; }
        public bool    HasSizes    { get; set; }
        public string  ImagePath   { get; set; }
        public Color   ThemeColor  { get; set; }

        // Size upcharges: Small = base, Medium = +₱20, Large = +₱40
        public decimal GetPriceForSize(string size)
        {
            if (!HasSizes || string.IsNullOrEmpty(size)) return BasePrice;
            if (size == "Medium") return BasePrice + 20m;
            if (size == "Large")  return BasePrice + 40m;
            return BasePrice; // Small
        }

        public MenuItem(int id, string name, string category, decimal basePrice,
                        string description, bool hasSizes, string imagePath, Color themeColor)
        {
            Id          = id;
            Name        = name;
            Category    = category;
            BasePrice   = basePrice;
            Description = description;
            HasSizes    = hasSizes;
            ImagePath   = imagePath;
            ThemeColor  = themeColor;
        }
    }
}
