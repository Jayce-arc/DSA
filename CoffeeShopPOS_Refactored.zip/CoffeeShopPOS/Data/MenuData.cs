using System.Collections.Generic;
using System.Drawing;
using CoffeeShopPOS.Models;

namespace CoffeeShopPOS.Data
{
    public static class MenuData
    {
        public static List<AddOn> GetAvailableAddOns()
        {
            return new List<AddOn>
            {
                new AddOn("Extra Shot",     30m),
                new AddOn("Whipped Cream",  20m),
                new AddOn("Oat Milk",       25m),
                new AddOn("Almond Milk",    25m),
                new AddOn("Vanilla Syrup",  15m),
                new AddOn("Caramel Syrup",  15m),
                new AddOn("Hazelnut Syrup", 15m),
                new AddOn("Brown Sugar",    10m),
                new AddOn("Extra Foam",     10m),
                new AddOn("No Sugar",        0m),
                new AddOn("Less Ice",        0m),
                new AddOn("No Ice",          0m),
            };
        }

        public static List<MenuItem> GetAllMenuItems()
        {
            return new List<MenuItem>
            {
                // ── Hot Coffee ──────────────────────────────────────────────
                new MenuItem( 1, "Americano",       "Hot Coffee", 120m,
                    "Bold espresso diluted with hot water",          true,  "./images/americano.jpg",       Color.FromArgb(101, 67, 33)),
                new MenuItem( 2, "Cappuccino",      "Hot Coffee", 135m,
                    "Equal parts espresso, steam & foam",            true,  "./images/cappuccino.jpg",      Color.FromArgb(160, 105, 60)),
                new MenuItem( 3, "Café Latte",      "Hot Coffee", 140m,
                    "Espresso with silky steamed milk",              true,  "./images/cafe_latte.jpg",      Color.FromArgb(188, 143, 95)),
                new MenuItem( 4, "Flat White",      "Hot Coffee", 150m,
                    "Double ristretto with velvety microfoam",       true,  "./images/flat_white.jpg",      Color.FromArgb(175, 125, 75)),
                new MenuItem( 5, "Mocha",           "Hot Coffee", 155m,
                    "Espresso, dark chocolate & steamed milk",       true,  "./images/mocha.jpg",           Color.FromArgb(85, 50, 28)),
                new MenuItem( 6, "Macchiato",       "Hot Coffee", 130m,
                    "Espresso 'stained' with a dash of foam",        true,  "./images/macchiato.jpg",       Color.FromArgb(145, 95, 50)),
                new MenuItem( 7, "Espresso",        "Hot Coffee", 100m,
                    "Pure concentrated double espresso shot",        false, "./images/espresso.jpg",        Color.FromArgb(55, 28, 12)),
                new MenuItem( 8, "Hazelnut Latte",  "Hot Coffee", 155m,
                    "Latte infused with toasted hazelnut",           true,  "./images/hazelnut_latte.jpg",  Color.FromArgb(155, 110, 60)),
                new MenuItem( 9, "Cortado",         "Hot Coffee", 125m,
                    "Espresso cut with equal warm milk",             false, "./images/cortado.jpg",         Color.FromArgb(130, 80, 45)),
                new MenuItem(10, "Vienna Coffee",   "Hot Coffee", 145m,
                    "Strong coffee crowned with whipped cream",      true,  "./images/vienna_coffee.jpg",   Color.FromArgb(120, 75, 40)),

                // ── Cold Coffee ─────────────────────────────────────────────
                new MenuItem(11, "Iced Americano",  "Cold Coffee", 130m,
                    "Chilled espresso over fresh ice",               true,  "./images/iced_americano.jpg",  Color.FromArgb(80, 50, 30)),
                new MenuItem(12, "Iced Latte",      "Cold Coffee", 150m,
                    "Espresso & cold milk poured over ice",          true,  "./images/iced_latte.jpg",      Color.FromArgb(200, 160, 110)),
                new MenuItem(13, "Cold Brew",       "Cold Coffee", 160m,
                    "12-hour slow-steeped cold extraction",          true,  "./images/cold_brew.jpg",       Color.FromArgb(55, 38, 22)),
                new MenuItem(14, "Frappe",          "Cold Coffee", 165m,
                    "Blended coffee, ice & cream delight",           true,  "./images/frappe.jpg",          Color.FromArgb(140, 100, 70)),
                new MenuItem(15, "Iced Mocha",      "Cold Coffee", 165m,
                    "Iced espresso swirled with chocolate",          true,  "./images/iced_mocha.jpg",      Color.FromArgb(65, 40, 25)),
                new MenuItem(16, "Matcha Latte",    "Cold Coffee", 160m,
                    "Premium ceremonial matcha with fresh milk",     true,  "./images/matcha_latte.jpg",    Color.FromArgb(106, 153, 85)),
                new MenuItem(17, "Caramel Macchiato","Cold Coffee",170m,
                    "Vanilla latte with golden caramel drizzle",     true,  "./images/caramel_macchiato.jpg",Color.FromArgb(185, 135, 75)),
                new MenuItem(18, "Brown Sugar Latte","Cold Coffee", 175m,
                    "Espresso with oat milk & brown sugar swirl",    true,  "./images/brown_sugar_latte.jpg",Color.FromArgb(158, 108, 52)),
                new MenuItem(19, "Dalgona Coffee",  "Cold Coffee", 165m,
                    "Whipped coffee foam over iced milk",            true,  "./images/dalgona_coffee.jpg",  Color.FromArgb(120, 85, 50)),

                // ── Pastries ────────────────────────────────────────────────
                new MenuItem(20, "Butter Croissant","Pastries",    85m,
                    "Flaky, golden, all-butter French croissant",    false, "./images/butter_croissant.jpg",Color.FromArgb(210, 170, 100)),
                new MenuItem(21, "Blueberry Muffin","Pastries",    90m,
                    "Moist muffin bursting with blueberries",        false, "./images/blueberry_muffin.jpg",Color.FromArgb(80, 65, 160)),
                new MenuItem(22, "Cinnamon Roll",   "Pastries",    95m,
                    "Soft pillowy roll glazed with cinnamon icing",  false, "./images/cinnamon_roll.jpg",   Color.FromArgb(200, 150, 90)),
                new MenuItem(23, "Choco Cake Slice","Pastries",   110m,
                    "Rich triple-layer dark chocolate cake",         false, "./images/choco_cake_slice.jpg",Color.FromArgb(55, 35, 20)),
                new MenuItem(24, "Cheesecake Slice","Pastries",   120m,
                    "Classic New York-style cream cheesecake",       false, "./images/cheesecake_slice.jpg",Color.FromArgb(250, 235, 195)),
                new MenuItem(25, "Banana Bread",    "Pastries",    80m,
                    "Warm, moist homemade banana loaf",              false, "./images/banana_bread.jpg",    Color.FromArgb(195, 155, 90)),
                new MenuItem(26, "Almond Danish",   "Pastries",    95m,
                    "Laminated pastry with almond frangipane",       false, "./images/almond_danish.jpg",   Color.FromArgb(220, 185, 120)),
                new MenuItem(27, "Strawberry Tart", "Pastries",   115m,
                    "Buttery tart shell with cream & strawberries",  false, "./images/strawberry_tart.jpg", Color.FromArgb(220, 80, 80)),
                new MenuItem(28, "Chocolate Muffin","Pastries",    90m,
                    "Double chocolate fudge muffin",                 false, "./images/chocolate_muffin.jpg",Color.FromArgb(60, 40, 25)),

                // ── Extras ──────────────────────────────────────────────────
                new MenuItem(29, "Hot Chocolate",   "Extras",     130m,
                    "Rich, velvety Valrhona hot chocolate",          true,  "./images/hot_chocolate.jpg",   Color.FromArgb(100, 60, 30)),
                new MenuItem(30, "Chai Tea Latte",  "Extras",     140m,
                    "Spiced masala chai with steamed milk",          true,  "./images/chai_tea_latte.jpg",  Color.FromArgb(195, 135, 80)),
                new MenuItem(31, "Mineral Water",   "Extras",      50m,
                    "Chilled still mineral water 500ml",             false, "./images/mineral_water.jpg",   Color.FromArgb(160, 200, 230)),
                new MenuItem(32, "Orange Juice",    "Extras",      90m,
                    "Freshly squeezed Valencia orange juice",        false, "./images/orange_juice.jpg",    Color.FromArgb(240, 160, 30)),
            };
        }

        public static List<string> GetCategories()
        {
            return new List<string> { "All", "Hot Coffee", "Cold Coffee", "Pastries", "Extras" };
        }
    }
}
